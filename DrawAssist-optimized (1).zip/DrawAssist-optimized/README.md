# DrawAssist v1.7 优化版

基于 v1.6 反编译后重写的核心代码，所有优化点已落地。

## 文件结构

```
app/src/main/java/com/drawassist/app/
├── MainActivity.kt                          # 主界面
├── process/
│   └── ImageProcessor.kt                     # 图像处理（优化后）
└── service/
    ├── OverlayService.kt                    # 悬浮窗（优化后）
    └── DrawAssistAccessibilityService.kt     # 作画服务（优化后）
```

## 已落地的 9 项优化

| # | 优化项 | 在代码哪里 |
|---|---|---|
| 1 | 路径加密（1.5px 等距重采样） | `ImageProcessor.densify()` |
| 2 | 多笔合并到一个 GestureDescription | `DrawAssistAccessibilityService.dispatchGestureBatch()` |
| 3 | TSP 最近邻路径排序 | `ImageProcessor.tspOrder()` |
| 4 | 起收笔微移动消 tap 圆点 | `ImageProcessor.addEndpointsPadding()` |
| 5 | 动态速度 0.2 px/ms | `DrawAssistAccessibilityService.estimateDuration()` |
| 6 | 自适应阈值 + RDP 容差 0.3 + Chaikin 平滑 | `ImageProcessor.processImage()` |
| 7 | 校准测试线 | `OverlayService.runCalibration()` |
| 8 | 对齐框可拖动 | `OverlayService.showAlignFrame()` |
| 9 | 短笔画过滤 + 毛刺修剪 + 段合并 | `ImageProcessor` 主流水线 |

## 关键参数位置

所有可调参数都集中在 `ImageProcessor.Companion` 里：

```kotlin
DP_EPS_RATIO = 0.3f        // RDP 容差，越小越精确
SPUR_MAX_LEN = 8f          // 毛刺修剪长度
MERGE_TOL = 4f             // 近邻合并容差
DENSIFY_STEP = 1.5f        // 路径加密间距
ADAPTIVE_BLOCK = 15       // 自适应阈值邻域
ADAPTIVE_C = 5             // 自适应阈值常数
```

作画速度参数在 `DrawAssistAccessibilityService.Companion`：

```kotlin
SPEED_PX_PER_MS = 0.2f     // 速度，0.15-0.25 是甜区
MAX_BATCH_DURATION_MS = 55_000L  // 单批手势上限
DEFAULT_GAP_MS = 15L       // 笔间间隔
```

## 使用流程

1. 选图 → 调阈值滑块 → 点「处理」
2. 开启悬浮窗权限 + 无障碍服务
3. 拖动对齐框套住绘画 App 画布
4. 点「校准」画测试线，看偏移
5. 点「开始」自动作画
