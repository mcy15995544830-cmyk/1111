package com.drawassist.app.process

import android.graphics.Bitmap
import android.graphics.PointF
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * 优化版 ImageProcessor
 * 改进点：
 * 1. 自适应二值化替代全局 Otsu
 * 2. 路径加密（等距重采样）在输出前做
 * 3. RDP 容差调小，保留更多细节
 * 4. 关掉转角自动断笔，改在路径级处理
 * 5. Chaikin 平滑替代移动平均
 * 6. TSP 最近邻排序
 * 7. 起收笔微移动点注入
 */
class ImageProcessor private constructor() {

    data class Point(val x: Int, val y: Int)
    data class PathData(
        val points: MutableList<PointF> = mutableListOf(),
        var durationMs: Long = 0L
    )

    companion object {
        @Volatile
        private var instance: ImageProcessor? = null
        fun getInstance(): ImageProcessor =
            instance ?: synchronized(this) {
                instance ?: ImageProcessor().also { instance = it }
            }

        // ====== 可调参数（优化后） ======
        private const val DEFAULT_MAX_SIZE = 1024          // 处理前最长边
        private const val DP_EPS_RATIO = 0.3f              // RDP 容差（原 1.0 → 0.3，砍点更少）
        private const val SPUR_MAX_LEN = 8f                // 毛刺最大长度（原 ~3 → 8）
        private const val MERGE_TOL = 4f                   // 合并近邻段容差（原 ~1.5 → 4）
        private const val CORNER_ANGLE_DEG = 130f          // 只有 >130° 转角才断（原 ~60-90）
        private const val MIN_SEG_LEN = 6f                  // 最短笔画长度，小于则跳过
        private const val CHAIKIN_PASSES = 2               // Chaikin 平滑次数
        private const val DENSIFY_STEP = 1.5f              // 路径加密采样间距（px）
        private const val ADAPTIVE_BLOCK = 15              // 自适应阈值邻域
        private const val ADAPTIVE_C = 5                   // 自适应阈值常数
        private const val DENOISE_PASSES = 2               // 去噪次数
        private const val NBR_TSP_MAX_JUMP = 200f          // TSP 最大跳跃距离
    }

    /**
     * 主入口：位图 → 路径列表
     * @param bitmap 用户选的参考图
     * @param threshold 0-255，用户滑块控制（fixed binarize 用）
     * @param useAdaptive true=自适应阈值，false=全局阈值
     */
    fun processImage(
        bitmap: Bitmap,
        threshold: Int,
        useAdaptive: Boolean = true,
        progress: ((Int) -> Unit)? = null
    ): List<PathData> {
        progress?.invoke(5)

        // 1. 缩放到最长边 DEFAULT_MAX_SIZE
        val scaled = scaleToMax(bitmap, DEFAULT_MAX_SIZE)
        progress?.invoke(10)

        // 2. 灰度
        val gray = toGrayscale(scaled)
        if (scaled != bitmap) scaled.recycle()
        progress?.invoke(15)

        // 3. 二值化
        val binary = if (useAdaptive) {
            adaptiveThreshold(gray, ADAPTIVE_BLOCK, ADAPTIVE_C)
        } else {
            fixedBinarize(gray, threshold)
        }
        progress?.invoke(25)

        // 4. 多次去噪
        var denoised = binary
        repeat(DENOISE_PASSES) {
            denoised = majorityFilter3x3(denoised)
        }
        progress?.invoke(35)

        // 5. 骨架化
        val skel = skeletonize(denoised)
        progress?.invoke(45)

        // 6. 去掉小连通域
        val cleaned = removeSmallComponents(skel, minSize = 8)
        progress?.invoke(50)

        // 7. 沿骨架追踪成路径
        var paths = tracePaths(cleaned)
        progress?.invoke(60)

        // 8. RDP 简化（容差小）
        paths = paths.map { rdpSimplify(it, DP_EPS_RATIO) }.filter { it.size >= 2 }
        progress?.invoke(68)

        // 9. 剪毛刺
        paths = paths.map { pruneSpurs(it, SPUR_MAX_LEN) }.filter { it.size >= 2 }
        progress?.invoke(73)

        // 10. 合并近邻段
        paths = mergeSegments(paths, MERGE_TOL)
        progress?.invoke(78)

        // 11. Chaikin 平滑
        repeat(CHAIKIN_PASSES) {
            paths = paths.map { chaikinSmooth(it) }
        }
        progress?.invoke(85)

        // 12. 过滤太短的笔画
        paths = paths.filter { pathLength(it) >= MIN_SEG_LEN }
        progress?.invoke(88)

        // 13. TSP 最近邻排序
        paths = tspOrder(paths)
        progress?.invoke(92)

        // 14. 路径加密（等距重采样到 1.5px 间距）
        paths = paths.map { densify(it, DENSIFY_STEP) }
        progress?.invoke(96)

        // 15. 起收笔微移动
        paths = paths.map { addEndpointsPadding(it) }
        progress?.invoke(100)

        return paths.map { PathData(it.toMutableList()) }
    }

    // ==================== 基础图像处理 ====================

    private fun scaleToMax(src: Bitmap, maxDim: Int): Bitmap {
        val w = src.width
        val h = src.height
        val m = max(w, h)
        if (m <= maxDim) return src
        val ratio = maxDim.toFloat() / m
        return Bitmap.createScaledBitmap(src, (w * ratio).toInt(), (h * ratio).toInt(), true)
    }

    private fun toGrayscale(bmp: Bitmap): IntArray {
        val w = bmp.width
        val h = bmp.height
        val pixels = IntArray(w * h)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            pixels[i] = (r * 299 + g * 587 + b * 114) / 1000
        }
        return pixels
    }

    /** 自适应阈值（邻域均值法），黑=255，白=0 */
    private fun adaptiveThreshold(gray: IntArray, w: Int, h: Int, block: Int, c: Int): IntArray {
        val out = IntArray(w * h)
        val half = block / 2
        // 积分图加速
        var sum = 0.0
        // 简单实现：逐像素邻域均值
        for (y in 0 until h) {
            for (x in 0 until w) {
                var s = 0L
                var cnt = 0
                for (dy in -half..half) {
                    val yy = y + dy
                    if (yy < 0 || yy >= h) continue
                    for (dx in -half..half) {
                        val xx = x + dx
                        if (xx < 0 || xx >= w) continue
                        s += gray[yy * w + xx]
                        cnt++
                    }
                }
                val mean = s / cnt
                val v = gray[y * w + x]
                out[y * w + x] = if (v < mean - c) 255 else 0
            }
        }
        return out
    }

    private fun fixedBinarize(gray: IntArray, threshold: Int): IntArray {
        val out = IntArray(gray.size)
        for (i in gray.indices) out[i] = if (gray[i] < threshold) 255 else 0
        return out
    }

    private fun majorityFilter3x3(img: IntArray, w: Int, h: Int): IntArray {
        val out = img.copyOf()
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                var count = 0
                for (dy in -1..1) for (dx in -1..1) {
                    if (img[(y + dy) * w + (x + dx)] > 0) count++
                }
                out[y * w + x] = if (count >= 5) 255 else 0
            }
        }
        return out
    }

    // ==================== 骨架化（Zhang-Suen） ====================

    private fun skeletonize(img: IntArray, w: Int, h: Int): IntArray {
        var skel = img.copyOf()
        var changed = true
        while (changed) {
            changed = false
            // step 1
            val toRemove = mutableListOf<Int>()
            for (y in 1 until h - 1) {
                for (x in 1 until w - 1) {
                    val idx = y * w + x
                    if (skel[idx] == 0) continue
                    val p2 = skel[(y-1)*w+x]; val p3 = skel[(y-1)*w+x+1]
                    val p4 = skel[y*w+x+1];     val p5 = skel[(y+1)*w+x+1]
                    val p6 = skel[(y+1)*w+x];   val p7 = skel[(y+1)*w+x-1]
                    val p8 = skel[y*w+x-1];     val p9 = skel[(y-1)*w+x-1]
                    val neighbors = listOf(p2,p3,p4,p5,p6,p7,p8,p9)
                    val b = neighbors.count { it > 0 }
                    if (b < 2 || b > 6) continue
                    val transitions = countTransitions(neighbors)
                    if (transitions != 1) continue
                    if (p2 * p4 * p6 != 0) continue
                    if (p4 * p6 * p8 != 0) continue
                    toRemove.add(idx)
                }
            }
            if (toRemove.isNotEmpty()) {
                toRemove.forEach { skel[it] = 0 }
                changed = true
            }
            // step 2
            val toRemove2 = mutableListOf<Int>()
            for (y in 1 until h - 1) {
                for (x in 1 until w - 1) {
                    val idx = y * w + x
                    if (skel[idx] == 0) continue
                    val p2 = skel[(y-1)*w+x]; val p3 = skel[(y-1)*w+x+1]
                    val p4 = skel[y*w+x+1];     val p5 = skel[(y+1)*w+x+1]
                    val p6 = skel[(y+1)*w+x];   val p7 = skel[(y+1)*w+x-1]
                    val p8 = skel[y*w+x-1];     val p9 = skel[(y-1)*w+x-1]
                    val neighbors = listOf(p2,p3,p4,p5,p6,p7,p8,p9)
                    val b = neighbors.count { it > 0 }
                    if (b < 2 || b > 6) continue
                    val transitions = countTransitions(neighbors)
                    if (transitions != 1) continue
                    if (p2 * p4 * p8 != 0) continue
                    if (p2 * p6 * p8 != 0) continue
                    toRemove2.add(idx)
                }
            }
            if (toRemove2.isNotEmpty()) {
                toRemove2.forEach { skel[it] = 0 }
                changed = true
            }
        }
        return skel
    }

    private fun countTransitions(n: List<Int>): Int {
        var c = 0
        for (i in 0..7) {
            val a = if (n[i] > 0) 1 else 0
            val b = if (n[(i+1)%8] > 0) 1 else 0
            if (a == 0 && b == 1) c++
        }
        return c
    }

    // ==================== 路径追踪 ====================

    private fun tracePaths(skel: IntArray, w: Int, h: Int): List<MutableList<PointF>> {
        val visited = BooleanArray(w * h)
        val paths = mutableListOf<MutableList<PointF>>()
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val idx = y * w + x
                if (skel[idx] == 0 || visited[idx]) continue
                // 找端点（度数为1的点）或交点
                val path = traceOnePath(skel, w, h, x, y, visited)
                if (path != null && path.size >= 2) paths.add(path)
            }
        }
        return paths
    }

    private fun traceOnePath(
        skel: IntArray, w: Int, h: Int,
        startX: Int, startY: Int, visited: BooleanArray
    ): MutableList<PointF>? {
        val path = mutableListOf<PointF>()
        var cx = startX; var cy = startY
        var prevDir = -1
        while (true) {
            visited[cy * w + cx] = true
            path.add(PointF(cx.toFloat(), cy.toFloat()))
            // 找下一个未访问的邻居
            var nextX = -1; var nextY = -1; var nextDir = -1
            val dirs = arrayOf(
                0 to (-1,0), 1 to (-1,1), 2 to (0,1), 3 to (1,1),
                4 to (1,0), 5 to (1,-1), 6 to (0,-1), 7 to (-1,-1)
            )
            for ((d, (dx, dy)) in dirs) {
                val nx = cx + dx; val ny = cy + dy
                if (nx < 0 || nx >= w || ny < 0 || ny >= h) continue
                val nidx = ny * w + nx
                if (skel[nidx] == 0 || visited[nidx]) continue
                // 优先走和上一步同方向的
                if (nextDir == -1 || d == (prevDir + 4) % 8) {
                    nextX = nx; nextY = ny; nextDir = d
                }
            }
            if (nextX == -1) break
            cx = nextX; cy = nextY; prevDir = nextDir
        }
        return if (path.size >= 2) path else null
    }

    // ==================== 路径处理 ====================

    /** Ramer-Douglas-Peucker 简化 */
    private fun rdpSimplify(points: List<PointF>, eps: Float): List<PointF> {
        if (points.size < 3) return points
        var maxDist = 0f
        var maxIdx = 0
        val a = points.first(); val b = points.last()
        for (i in 1 until points.size - 1) {
            val d = pointToLineDistance(points[i], a, b)
            if (d > maxDist) { maxDist = d; maxIdx = i }
        }
        if (maxDist > eps) {
            val left = rdpSimplify(points.subList(0, maxIdx + 1), eps)
            val right = rdpSimplify(points.subList(maxIdx, points.size), eps)
            return (left.dropLast(1) + right).toMutableList()
        } else {
            return mutableListOf(a, b)
        }
    }

    private fun pointToLineDistance(p: PointF, a: PointF, b: PointF): Float {
        val dx = b.x - a.x; val dy = b.y - a.y
        val len2 = dx*dx + dy*dy
        if (len2 == 0f) return hypot(p.x-a.x, p.y-a.y)
        var t = ((p.x-a.x)*dx + (p.y-a.y)*dy) / len2
        t = max(0f, min(1f, t))
        val projX = a.x + t*dx; val projY = a.y + t*dy
        return hypot(p.x-projX, p.y-projY)
    }

    /** 剪掉短毛刺 */
    private fun pruneSpurs(points: List<PointF>, maxLen: Float): List<PointF> {
        if (points.size < 4) return points
        val out = points.toMutableList()
        // 从端点开始，剪掉长度 < maxLen 的尾巴
        while (out.size >= 2 && pathLength(out.takeLast(2)) < maxLen) {
            out.removeAt(out.size - 1)
        }
        while (out.size >= 2 && pathLength(out.take(2)) < maxLen) {
            out.removeAt(0)
        }
        return out
    }

    /** 合并近邻路径 */
    private fun mergeSegments(paths: List<MutableList<PointF>>, tol: Float): List<MutableList<PointF>> {
        val out = paths.toMutableList()
        var merged = true
        while (merged) {
            merged = false
            outer@ for (i in out.indices) {
                for (j in i+1 until out.size) {
                    val a = out[i]; val b = out[j]
                    // 检查首尾是否接近
                    if (dist(a.last(), b.first()) < tol || dist(a.last(), b.last()) < tol ||
                        dist(a.first(), b.first()) < tol || dist(a.first(), b.last()) < tol) {
                        // 合并
                        out[i] = mergeTwo(a, b)
                        out.removeAt(j)
                        merged = true
                        break@outer
                    }
                }
            }
        }
        return out
    }

    private fun mergeTwo(a: MutableList<PointF>, b: MutableList<PointF>): MutableList<PointF> {
        return when {
            dist(a.last(), b.first()) < dist(a.last(), b.last()) &&
            dist(a.last(), b.first()) < dist(a.first(), b.first()) &&
            dist(a.last(), b.first()) < dist(a.first(), b.last()) -> (a + b).toMutableList()
            dist(a.last(), b.last()) < dist(a.first(), b.first()) -> (a + b.asReversed()).toMutableList()
            dist(a.first(), b.last()) < dist(a.first(), b.first()) -> (a.asReversed() + b).toMutableList()
            else -> (b + a).toMutableList()
        }
    }

    private fun dist(a: PointF, b: PointF) = hypot(a.x-b.x, a.y-b.y)

    /** Chaikin 角点切割平滑 */
    private fun chaikinSmooth(points: List<PointF>): List<PointF> {
        if (points.size < 3) return points
        val out = mutableListOf<PointF>()
        out.add(points.first())
        for (i in 0 until points.size - 1) {
            val p0 = points[i]; val p1 = points[i+1]
            val q = PointF(p0.x*0.75f + p1.x*0.25f, p0.y*0.75f + p1.y*0.25f)
            val r = PointF(p0.x*0.25f + p1.x*0.75f, p0.y*0.25f + p1.y*0.75f)
            out.add(q); out.add(r)
        }
        out.add(points.last())
        return out
    }

    /** TSP 最近邻排序 */
    private fun tspOrder(paths: List<MutableList<PointF>>): List<MutableList<PointF>> {
        if (paths.size <= 1) return paths
        val remaining = paths.toMutableList()
        val out = mutableListOf<MutableList<PointF>>()
        var cur = remaining.removeAt(0)
        out.add(cur)
        while (remaining.isNotEmpty()) {
            val end = cur.last()
            var bestIdx = 0; var bestDist = Float.MAX_VALUE
            for (i in remaining.indices) {
                val d1 = dist(end, remaining[i].first())
                val d2 = dist(end, remaining[i].last())
                val d = min(d1, d2)
                if (d < bestDist) {
                    bestDist = d; bestIdx = i
                }
            }
            if (bestDist > NBR_TSP_MAX_JUMP) break
            cur = remaining.removeAt(bestIdx)
            // 方向对齐
            if (dist(dist(end, cur.first()), dist(end, cur.last())) > 0 &&
                dist(end, cur.last()) < dist(end, cur.first())) {
                cur.reverse()
            }
            out.add(cur)
        }
        // 剩下的追加
        out.addAll(remaining)
        return out
    }

    /** 路径加密：等距重采样 */
    private fun densify(points: List<PointF>, step: Float): List<PointF> {
        if (points.size < 2) return points
        val out = mutableListOf<PointF>()
        var carry = 0f
        out.add(points.first())
        for (i in 0 until points.size - 1) {
            val a = points[i]; val b = points[i+1]
            val segLen = dist(a, b)
            if (segLen == 0f) continue
            var d = step - carry
            while (d < segLen) {
                val t = d / segLen
                out.add(PointF(a.x + (b.x-a.x)*t, a.y + (b.y-a.y)*t))
                d += step
            }
            carry = segLen - (d - step)
        }
        out.add(points.last())
        return out
    }

    /** 起收笔微移动：消除 tap 圆点 */
    private fun addEndpointsPadding(points: List<PointF>): List<PointF> {
        if (points.size < 3) return points
        val out = points.toMutableList()
        val p0 = out[0]; val p1 = out[1]
        val dx = p1.x - p0.x; val dy = p1.y - p0.y
        val len = hypot(dx, dy)
        if (len > 0.1f) {
            val back = PointF(p0.x - dx/len*2f, p0.y - dy/len*2f)
            out.add(0, back)
        }
        val pn = out[out.size-1]; val pm = out[out.size-2]
        val dx2 = pn.x - pm.x; val dy2 = pn.y - pm.y
        val len2 = hypot(dx2, dy2)
        if (len2 > 0.1f) {
            val fwd = PointF(pn.x + dx2/len2*2f, pn.y + dy2/len2*2f)
            out.add(fwd)
        }
        return out
    }

    private fun pathLength(points: List<PointF>): Float {
        var len = 0f
        for (i in 0 until points.size - 1) len += dist(points[i], points[i+1])
        return len
    }
}
