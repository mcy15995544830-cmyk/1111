package com.drawassist.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.drawassist.app.process.ImageProcessor
import kotlin.math.hypot

/**
 * 优化版无障碍作画服务
 * 改进点：
 * 1. 多笔合并到一个 GestureDescription，消除笔间 Binder 延迟
 * 2. 路径已在 ImageProcessor 加密，直接喂 StrokeDescription
 * 3. 动态 duration 按路径长度算
 * 4. 批次大小控制，单批不超过 60s
 * 5. 校准 offset 补偿
 */
class DrawAssistAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "DrawA11y"
        const val MAX_BATCH_DURATION_MS = 55_000L   // 单批手势最长 55s（留余量）
        const val DEFAULT_GAP_MS = 15L               // 笔间间隔
        const val SPEED_PX_PER_MS = 0.2f             // 0.2 px/ms ≈ 20cm/s
        const val MIN_STROKE_MS = 30L
        const val MAX_STROKE_MS = 8_000L
    }

    interface DrawCallback {
        fun onStrokeComplete(index: Int, total: Int)
        fun onBatchComplete()
        fun onDrawFinished()
        fun onDrawInterrupted()
    }

    @Volatile
    private var callback: DrawCallback? = null

    @Volatile
    private var stopRequested = false

    // 校准偏移
    var calibOffsetX = 0f
    var calibOffsetY = 0f

    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        stopRequested = true
        return super.onUnbind(intent)
    }

    /**
     * 开始作画
     * @param paths 已经映射到屏幕坐标的路径列表（ImageProcessor 输出 + mapToScreen）
     * @param speedPxPerMs 速度
     * @param cb 回调
     */
    fun performBatchDraw(
        paths: List<List<android.graphics.PointF>>,
        speedPxPerMs: Float = SPEED_PX_PER_MS,
        cb: DrawCallback
    ) {
        callback = cb
        stopRequested = false

        // 把路径分批
        val batches = mutableListOf<List<List<android.graphics.PointF>>>()
        var currentBatch = mutableListOf<List<android.graphics.PointF>>()
        var currentDuration = 0L

        for (path in paths) {
            val dur = estimateDuration(path, speedPxPerMs)
            if (currentDuration + dur > MAX_BATCH_DURATION_MS && currentBatch.isNotEmpty()) {
                batches.add(currentBatch)
                currentBatch = mutableListOf()
                currentDuration = 0L
            }
            currentBatch.add(path)
            currentDuration += dur + DEFAULT_GAP_MS
        }
        if (currentBatch.isNotEmpty()) batches.add(currentBatch)

        Log.i(TAG, "Total paths=${paths.size}, batches=${batches.size}")

        var batchIdx = 0
        fun dispatchNextBatch() {
            if (stopRequested) {
                cb.onDrawInterrupted()
                return
            }
            if (batchIdx >= batches.size) {
                cb.onDrawFinished()
                return
            }
            val batch = batches[batchIdx]
            dispatchGestureBatch(batch, speedPxPerMs, object : ResultCallback() {
                override fun onGestureCompleted(gestureDescription: GestureDescription) {
                    mainHandler.post {
                        cb.onBatchComplete()
                        batchIdx++
                        dispatchNextBatch()
                    }
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    mainHandler.post { cb.onDrawInterrupted() }
                }
            })
        }

        dispatchNextBatch()
    }

    /**
     * 把一批路径打包成一个 GestureDescription 一次性 dispatch
     */
    private fun dispatchGestureBatch(
        batch: List<List<android.graphics.PointF>>,
        speedPxPerMs: Float,
        resultCallback: ResultCallback
    ) {
        val builder = GestureDescription.Builder()
        var offset = 0L

        for (pathPoints in batch) {
            if (pathPoints.size < 2) continue

            // 转成 Android Path，加上校准偏移
            val androidPath = Path()
            androidPath.moveTo(pathPoints[0].x + calibOffsetX, pathPoints[0].y + calibOffsetY)
            for (i in 1 until pathPoints.size) {
                androidPath.lineTo(pathPoints[i].x + calibOffsetX, pathPoints[i].y + calibOffsetY)
            }

            val duration = estimateDuration(pathPoints, speedPxPerMs)
            val stroke = GestureDescription.StrokeDescription(
                androidPath,
                offset,
                duration
            )
            builder.addStroke(stroke)
            offset += duration + DEFAULT_GAP_MS
        }

        val gesture = builder.build()
        dispatchGesture(gesture, resultCallback, mainHandler)
    }

    /**
     * 按路径长度动态算 duration
     */
    private fun estimateDuration(path: List<android.graphics.PointF>, speed: Float): Long {
        var len = 0f
        for (i in 0 until path.size - 1) {
            len += hypot(
                path[i+1].x - path[i].x,
                path[i+1].y - path[i].y
            )
        }
        return (len / speed).toLong().coerceIn(MIN_STROKE_MS, MAX_STROKE_MS)
    }

    fun stop() {
        stopRequested = true
    }
}
