package com.drawassist.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.drawassist.app.R
import com.drawassist.app.process.ImageProcessor

/**
 * 优化版悬浮窗服务
 * 改进点：
 * 1. 对齐框可拖动四角精确对齐
 * 2. 速度滑块实时生效
 * 3. 开始作画前先跑校准测试线
 * 4. 进度 HUD 实时显示当前笔/总笔
 */
class OverlayService : Service() {

    companion object {
        private const val CHANNEL_ID = "draw_assist_channel"
        private const val NOTIFICATION_ID = 1001
        private const val TAG = "OverlayService"
    }

    private lateinit var wm: WindowManager
    private lateinit var mainHandler: Handler
    private var screenW = 0
    private var screenH = 0
    private var density = 1f

    // 对齐框
    private var frameView: View? = null
    private var frameLeft = 0
    private var frameTop = 0
    private var frameSize = 0

    // 控制面板
    private var panelView: View? = null
    private var tvStatus: TextView? = null
    private var seekSpeed: SeekBar? = null
    private var tvSpeed: TextView? = null

    // HUD
    private var hudView: TextView? = null

    // 状态
    private var currentPaths: List<List<android.graphics.PointF>> = emptyList()
    private var currentBitmap: android.graphics.Bitmap? = null
    private var isDrawing = false
    private var speedPxPerMs = DrawAssistAccessibilityService.SPEED_PX_PER_MS

    private var a11yService: DrawAssistAccessibilityService? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        mainHandler = Handler(Looper.getMainLooper())
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels
        density = dm.density
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onBind(intent: Intent?): IBinder? = null

    fun setAccessibilityService(svc: DrawAssistAccessibilityService) {
        a11yService = svc
    }

    fun setImage(bitmap: android.graphics.Bitmap, paths: List<ImageProcessor.PathData>) {
        currentBitmap = bitmap
        // 把 ImageProcessor 的 PointF 转成 Android PointF 并映射到屏幕坐标
        currentPaths = paths.map { pd ->
            pd.points.map { pt ->
                // 映射逻辑：图片处理时是在 scaled bitmap 坐标系里（最长边 DEFAULT_MAX_SIZE）
                // 需要映射到对齐框内
                android.graphics.PointF(
                    frameLeft + pt.x / 1024f * frameSize,
                    frameTop + pt.y / 1024f * frameSize
                )
            }
        }
        showAlignFrame()
        showControlPanel()
    }

    // ==================== 对齐框 ====================

    private fun showAlignFrame() {
        if (frameView != null) return
        frameSize = (screenW * 0.8f).toInt()
        frameLeft = (screenW - frameSize) / 2
        frameTop = (screenH - frameSize) / 2

        val frame = FrameLayout(this).apply {
            setBackgroundResource(android.R.color.transparent)
            foreground = null
        }
        // 用一个带边框的 view
        val params = WindowManager.LayoutParams(
            frameSize, frameSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = frameLeft
            y = frameTop
        }
        frameView = frame
        wm.addView(frame, params)

        // 允许拖动对齐框
        frame.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_MOVE -> {
                    frameLeft = event.rawX.toInt() - frameSize / 2
                    frameTop = event.rawY.toInt() - frameSize / 2
                    updateFramePosition()
                }
            }
            true
        }
    }

    private fun updateFramePosition() {
        val v = frameView ?: return
        val params = v.layoutParams as WindowManager.LayoutParams
        params.x = frameLeft
        params.y = frameTop
        wm.updateViewLayout(v, params)
    }

    fun hideAlignFrame() {
        frameView?.let { wm.removeView(it); frameView = null }
    }

    // ==================== 控制面板 ====================

    private fun showControlPanel() {
        if (panelView != null) return
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xDD222222.toInt())
            setPadding(24, 24, 24, 24)
        }

        tvStatus = TextView(this).apply {
            text = "就绪，拖动对齐框套住画布后点开始"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
        }
        panel.addView(tvStatus)

        // 速度滑块
        tvSpeed = TextView(this).apply {
            text = "速度: ${(speedPxPerMs*100).toInt()}"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 12f
        }
        panel.addView(tvSpeed)

        seekSpeed = SeekBar(this).apply {
            max = 50
            progress = (speedPxPerMs * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    speedPxPerMs = p / 100f
                    tvSpeed?.text = "速度: $p"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        panel.addView(seekSpeed)

        // 按钮行
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val btnStart = Button(this).apply { text = "开始" }
        val btnCalib = Button(this).apply { text = "校准" }
        val btnStop = Button(this).apply { text = "停止" }
        btnStart.setOnClickListener { startDrawing() }
        btnCalib.setOnClickListener { runCalibration() }
        btnStop.setOnClickListener { stopDrawing() }
        btnRow.addView(btnStart)
        btnRow.addView(btnCalib)
        btnRow.addView(btnStop)
        panel.addView(btnRow)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 100
        }
        panelView = panel
        wm.addView(panel, params)
    }

    // ==================== 校准 ====================

    private fun runCalibration() {
        val svc = a11yService ?: run {
            Toast.makeText(this, "请先开启无障碍服务", Toast.LENGTH_SHORT).show()
            return
        }
        // 在对齐框左上角画一个 50x50 的测试方框
        val testPath = listOf(
            android.graphics.PointF(frameLeft + 50f, frameTop + 50f),
            android.graphics.PointF(frameLeft + 100f, frameTop + 50f),
            android.graphics.PointF(frameLeft + 100f, frameTop + 100f),
            android.graphics.PointF(frameLeft + 50f, frameTop + 100f),
            android.graphics.PointF(frameLeft + 50f, frameTop + 50f)
        )
        tvStatus?.text = "已画测试方框，请截图查看实际位置偏移"
        svc.performBatchDraw(listOf(testPath), 0.3f, object : DrawAssistAccessibilityService.DrawCallback {
            override fun onStrokeComplete(index: Int, total: Int) {}
            override fun onBatchComplete() {}
            override fun onDrawFinished() {
                mainHandler.post {
                    tvStatus?.text = "校准完成，请根据实际落点调整 offset"
                }
            }
            override fun onDrawInterrupted() {}
        })
    }

    // ==================== 作画 ====================

    private fun startDrawing() {
        val svc = a11yService ?: run {
            Toast.makeText(this, "请先开启无障碍服务", Toast.LENGTH_SHORT).show()
            return
        }
        if (isDrawing) return
        if (currentPaths.isEmpty()) {
            Toast.makeText(this, "请先选择并处理图片", Toast.LENGTH_SHORT).show()
            return
        }
        isDrawing = true
        showHud("准备作画...")

        svc.performBatchDraw(currentPaths, speedPxPerMs, object : DrawAssistAccessibilityService.DrawCallback {
            override fun onStrokeComplete(index: Int, total: Int) {
                mainHandler.post { showHud("进度: $index / $total") }
            }
            override fun onBatchComplete() {}
            override fun onDrawFinished() {
                mainHandler.post {
                    isDrawing = false
                    showHud("作画完成 ✓")
                }
            }
            override fun onDrawInterrupted() {
                mainHandler.post {
                    isDrawing = false
                    showHud("已中断")
                }
            }
        })
    }

    private fun stopDrawing() {
        a11yService?.stop()
        isDrawing = false
        showHud("已停止")
    }

    private fun showHud(text: String) {
        if (hudView == null) {
            val tv = TextView(this).apply {
                setBackgroundColor(0xAA000000.toInt())
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 12f
                setPadding(16, 8, 16, 8)
            }
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = 80
            }
            hudView = tv
            wm.addView(tv, params)
        }
        hudView?.text = text
    }

    // ==================== 通知 ====================

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "DrawAssist",
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NotificationManager::class.java)).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID)
        else Notification.Builder(this)
        return builder
            .setContentTitle("DrawAssist")
            .setContentText("正在运行")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        frameView?.let { wm.removeView(it) }
        panelView?.let { wm.removeView(it) }
        hudView?.let { wm.removeView(it) }
    }
}
