package com.drawassist.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.drawassist.app.process.ImageProcessor
import com.drawassist.app.service.OverlayService

class MainActivity : Activity() {

    private lateinit var ivPreview: ImageView
    private lateinit var seekThreshold: SeekBar
    private lateinit var tvThreshold: TextView
    private lateinit var btnProcess: Button
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar

    private var selectedBitmap: Bitmap? = null
    private var processedPaths: List<ImageProcessor.PathData> = emptyList()
    private var threshold = 128

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        loadImage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ivPreview = findViewById(R.id.imageView)
        seekThreshold = findViewById(R.id.seekThreshold)
        tvThreshold = findViewById(R.id.tvThreshold)
        btnProcess = findViewById(R.id.btnProcess)
        btnStart = findViewById(R.id.btnStartOverlay)
        btnStop = findViewById(R.id.btnStopOverlay)
        tvStatus = findViewById(R.id.tvStatus)
        progressBar = findViewById(R.id.progressBar)

        findViewById<Button>(R.id.btnSelectImage).setOnClickListener {
            imagePicker.launch("image/*")
        }

        seekThreshold.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                threshold = p
                tvThreshold?.text = "阈值: $p"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        btnProcess.setOnClickListener { processSelected() }
        btnStart.setOnClickListener { startOverlay() }
        btnStop.setOnClickListener { stopOverlay() }
    }

    private fun loadImage(uri: Uri) {
        contentResolver.openInputStream(uri)?.use { stream ->
            selectedBitmap = BitmapFactory.decodeStream(stream)
            ivPreview.setImageBitmap(selectedBitmap)
            tvStatus.text = "图片已加载，点「处理」提取路径"
        }
    }

    private fun processSelected() {
        val bmp = selectedBitmap ?: run {
            Toast.makeText(this, "请先选图", Toast.LENGTH_SHORT).show()
            return
        }
        progressBar.visibility = android.view.View.VISIBLE
        tvStatus.text = "处理中..."

        Thread {
            try {
                val processor = ImageProcessor.getInstance()
                processedPaths = processor.processImage(bmp, threshold, useAdaptive = true) { p ->
                    runOnUiThread { progressBar.progress = p }
                }
                runOnUiThread {
                    progressBar.visibility = android.view.View.GONE
                    tvStatus.text = "处理完成 ✓ 共 ${processedPaths.size} 笔"
                    btnStart.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progressBar.visibility = android.view.View.GONE
                    tvStatus.text = "处理失败: ${e.message}"
                }
            }
        }.start()
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            return
        }
        val bmp = selectedBitmap ?: return
        val svc = Intent(this, OverlayService::class.java).apply {
            putExtra("has_image", true)
        }
        startForegroundService(svc)
        tvStatus.text = "悬浮窗已启动，拖动对齐框后点开始"
    }

    private fun stopOverlay() {
        stopService(Intent(this, OverlayService::class.java))
        tvStatus.text = "已停止"
    }
}
