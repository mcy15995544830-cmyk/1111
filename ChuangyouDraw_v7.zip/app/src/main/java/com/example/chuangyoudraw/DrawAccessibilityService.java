package com.example.chuangyoudraw;

import android.accessibilityservice.AccessibilityService;

/**
 * 无障碍服务：持有实例供 AndroidBridge 调用 dispatchGesture，
 * 从而在“创游世界”画板上按对齐坐标自动点击。
 * 需用户在系统【无障碍】中手动开启本服务。
 */
public class DrawAccessibilityService extends AccessibilityService {

    private static DrawAccessibilityService instance = null;

    public static DrawAccessibilityService getInstance() {
        return instance;
    }

    @Override
    public void onServiceConnected() {
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent event) {
        // 无需处理事件，仅用于提供手势能力
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }
}
