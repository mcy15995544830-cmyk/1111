package com.example.chuangyoudraw;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;

/**
 * 透明中介 Activity：承接 WebView 的 onShowFileChooser，
 * 弹出系统文件选择器并回传结果给悬浮窗里的 WebView。
 * 悬浮窗是 Service，无法直接 startActivityForResult，需借助本 Activity。
 */
public class FilePickActivity extends Activity {

    private static ValueCallback<Uri[]> pendingCallback = null;

    /** 由 FloatService 的 onShowFileChooser 调用。 */
    public static void start(Context ctx, ValueCallback<Uri[]> callback) {
        pendingCallback = callback;
        Intent i = new Intent(ctx, FilePickActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 透明背景
        getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.setType("image/*");
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(pick, 1);
        } catch (Exception e) {
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (pendingCallback != null) {
            pendingCallback.onReceiveValue(
                    WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            pendingCallback = null;
        }
        finish();
    }

    @Override
    protected void onDestroy() {
        if (pendingCallback != null) {
            pendingCallback.onReceiveValue(null);
            pendingCallback = null;
        }
        super.onDestroy();
    }
}
