package com.example.chuangyoudraw;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.Manifest;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * 主界面：选线稿图、申请悬浮窗权限、启动/关闭悬浮窗、跳转无障碍设置。
 */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Android 13+：悬浮窗前台服务需要通知权限
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }

        Button start = findViewById(R.id.btnStart);
        Button perm  = findViewById(R.id.btnPerm);
        Button stop  = findViewById(R.id.btnStop);
        Button pick  = findViewById(R.id.btnPick);

        // 选择线稿图：在前台 Activity 里选图（后台悬浮窗无法弹出选图窗口）
        pick.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "请先授予“显示在其他应用上层”权限", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
                return;
            }
            Intent g = new Intent(Intent.ACTION_GET_CONTENT);
            g.setType("image/*");
            g.addCategory(Intent.CATEGORY_OPENABLE);
            try {
                startActivityForResult(g, 1);
            } catch (Exception e) {
                Toast.makeText(this, "无法打开图片选择器", Toast.LENGTH_SHORT).show();
            }
        });

        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "需要先授予“显示在其他应用上层”权限", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
                return;
            }
            // Android 13+：前台服务需要通知权限，未授予就引导授权，否则启动会崩溃
            if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "请先允许“通知”权限（悬浮窗前台服务需要），授权后再点一次开启", Toast.LENGTH_LONG).show();
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
                return;
            }
            Intent svc = new Intent(this, FloatService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(svc);
            } else {
                startService(svc);
            }
            Toast.makeText(this,
                    "悬浮窗已开启。请再到系统【无障碍】里打开本应用的“自动绘制服务”，否则无法自动点击画板。",
                    Toast.LENGTH_LONG).show();
        });

        perm.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        stop.setOnClickListener(v -> stopService(new Intent(this, FloatService.class)));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                Uri uri = data.getData();
                InputStream is = getContentResolver().openInputStream(uri);
                Bitmap bmp = BitmapFactory.decodeStream(is);
                if (is != null) is.close();
                if (bmp != null) {
                    // 缩放，避免超大图
                    int max = 2048;
                    int w = bmp.getWidth(), h = bmp.getHeight();
                    if (Math.max(w, h) > max) {
                        float scale = (float) max / Math.max(w, h);
                        bmp = Bitmap.createScaledBitmap(bmp, (int) (w * scale), (int) (h * scale), true);
                    }
                    File out = new File(getFilesDir(), "lineart.png");
                    FileOutputStream fos = new FileOutputStream(out);
                    bmp.compress(Bitmap.CompressFormat.PNG, 90, fos);
                    fos.close();
                    Toast.makeText(this, "线稿已导入，正在启动悬浮窗", Toast.LENGTH_SHORT).show();
                    // 启动/更新悬浮窗并传入图片
                    if (Build.VERSION.SDK_INT >= 26) {
                        Intent s = new Intent(this, FloatService.class);
                        s.putExtra("imagePath", out.getAbsolutePath());
                        startForegroundService(s);
                    }
                }
            } catch (Exception e) {
                Toast.makeText(this, "导入失败", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
