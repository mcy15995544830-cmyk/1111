package com.example.chuangyoudraw;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

/**
 * JS 桥接对象，注入为 window.AndroidBridge。
 * HTML 侧已按优先级调用：
 *   drawPointAligned(nx, ny) —— 归一化坐标(0~1)，已含对齐方框结果
 *   drawPoint(x, y, gridSize) —— 旧接口，无对齐时回退
 *   onDrawStart() / onDrawEnd() —— 绘制开始 / 完成通知
 */
public class AndroidBridge {

    private final WebView web;

    public AndroidBridge(WebView web) {
        this.web = web;
    }

    /** 对齐后调用：nx/ny 为相对整个悬浮窗视口的归一化坐标(0~1)。 */
    @JavascriptInterface
    public void drawPointAligned(final double nx, final double ny) {
        web.post(new Runnable() {
            @Override
            public void run() {
                int w = web.getWidth();
                int h = web.getHeight();
                tap((int) Math.round(nx * w), (int) Math.round(ny * h));
            }
        });
    }

    /** 旧接口回退：无对齐时按网格比例铺满居中。 */
    @JavascriptInterface
    public void drawPoint(final int x, final int y, final int gridSize) {
        web.post(new Runnable() {
            @Override
            public void run() {
                int w = web.getWidth();
                int h = web.getHeight();
                int size = Math.min(w, h);
                int px = (w - size) / 2 + (int) ((x / (double) gridSize) * size);
                int py = (h - size) / 2 + (int) ((y / (double) gridSize) * size);
                tap(px, py);
            }
        });
    }

    @JavascriptInterface
    public void onDrawStart() {
        // 可选：绘制开始时做点什么
    }

    @JavascriptInterface
    public void onDrawEnd() {
        // 可选：绘制完成时做点什么
    }

    /** 通过无障碍服务在 (x, y) 处模拟一次点击（落到下层创游世界画板）。 */
    private void tap(int x, int y) {
        AccessibilityService svc = DrawAccessibilityService.getInstance();
        if (svc == null) {
            return; // 无障碍未开启，无法点击
        }
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 30))
                .build();
        svc.dispatchGesture(gesture, null, null);
    }
}
