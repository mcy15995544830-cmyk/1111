package com.example.chuangyoudraw;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Toast;

/**
 * 主界面：申请悬浮窗权限、启动/关闭悬浮窗、跳转无障碍设置。
 */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button start = findViewById(R.id.btnStart);
        Button perm  = findViewById(R.id.btnPerm);
        Button stop  = findViewById(R.id.btnStop);

        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "需要先授予“显示在其他应用上层”权限", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
                return;
            }
            startService(new Intent(this, FloatService.class));
            Toast.makeText(this,
                    "悬浮窗已开启。请再到系统【无障碍】里打开本应用的“自动绘制服务”，否则无法自动点击画板。",
                    Toast.LENGTH_LONG).show();
        });

        perm.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        stop.setOnClickListener(v -> stopService(new Intent(this, FloatService.class)));
    }
}
