package com.example.chuangyoudraw;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.util.Base64;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

/**
 * 悬浮窗服务：把承载工具界面的 WebView 作为系统悬浮窗盖在“创游世界”上层。
 * - WebView 背景透明、页面用半透明模式，透出画板用于对齐
 * - 配 WebChromeClient，使“导入线稿”能弹出系统文件选择器
 * - 提供 close()，供 HTML 内“关闭”按钮通过桥接调用，可退出悬浮窗
 */
public class FloatService extends Service {

    private WindowManager wm;
    private FrameLayout container;
    private WebView web;
    private TextView dragBar = null;
    private FrameLayout overlayBtn = null;
    private String pendingImagePath = null;

    // 拖动条：把悬浮窗整体拖到创游世界画板上
    private final View.OnTouchListener dragTouch = new View.OnTouchListener() {
        private float startX, startY;
        private int startLpX, startLpY;

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) container.getLayoutParams();
            if (lp == null) return false;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    startX = e.getRawX();
                    startY = e.getRawY();
                    startLpX = lp.x;
                    startLpY = lp.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    lp.x = startLpX + (int) (e.getRawX() - startX);
                    lp.y = startLpY + (int) (e.getRawY() - startY);
                    try {
                        wm.updateViewLayout(container, lp);
                    } catch (Exception ignored) {
                    }
                    return true;
            }
            return false;
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra("imagePath")) {
            pendingImagePath = intent.getStringExtra("imagePath");
            if (web != null && web.getUrl() != null) {
                injectImage();
            }
        }
        return START_STICKY;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        // 前台服务：保证悬浮窗稳定，并允许从悬浮窗弹出系统文件选择器
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    "float", "悬浮窗服务", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
        Notification notif = new Notification.Builder(this, "float")
                .setContentTitle("创游世界描摹工具")
                .setContentText("悬浮窗运行中，可返回画板对齐")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .build();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                // Android 10+ 必须显式指定与 Manifest 一致的前台服务类型，否则崩溃
                startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            } else {
                startForeground(1, notif);
            }
        } catch (Exception e) {
            // 通知权限未授予等极端情况：忽略，悬浮窗仍可运行
        }

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        container = new FrameLayout(this);
        container.setBackgroundColor(0x99060A12);

        // 顶部拖动条：按住可整体移动悬浮窗到画板上
        dragBar = new TextView(this);
        dragBar.setText("≡  按住这里拖动悬浮窗  ·  对齐画板后点【锁定】");
        dragBar.setTextColor(Color.WHITE);
        dragBar.setTextSize(12);
        dragBar.setGravity(Gravity.CENTER);
        dragBar.setBackgroundColor(0x33000000);
        container.addView(dragBar, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(34)));
        dragBar.setOnTouchListener(dragTouch);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowFileAccess(true);
        web.setBackgroundColor(0x00000000);

        // 注入桥接（含关闭悬浮窗回调）
        web.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");

        // 文件选择：让“导入线稿原图”能弹出系统文件选择器
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view,
                                             ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                FilePickActivity.start(FloatService.this, filePathCallback);
                return true;
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("document.body.classList.add('overlay');", null);
                injectImage();
            }
        });

        web.loadUrl("file:///android_asset/tool.html");

        // WebView 放在拖动条下方，填充剩余区域
        FrameLayout.LayoutParams webLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
        webLp.topMargin = dp(34);
        container.addView(web, webLp);

        // 小悬浮窗：只占屏幕一部分，窗口外可点击下层应用
        int sw = getResources().getDisplayMetrics().widthPixels;
        int sh = getResources().getDisplayMetrics().heightPixels;
        int winW = (int) (sw * 0.92);
        int winH = (int) (sh * 0.80);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                winW, winH,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = (sw - winW) / 2;
        lp.y = (sh - winH) / 2;
        wm.addView(container, lp);
    }

    public WebView getWebView() {
        return web;
    }

    /** HTML 内“关闭”按钮调用：退出悬浮窗（桥接回调可能不在主线程，post 到主线程执行）。 */
    public void close() {
        if (web != null) {
            web.post(new Runnable() {
                @Override
                public void run() {
                    doClose();
                }
            });
        } else {
            doClose();
        }
    }

    private void doClose() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        if (container != null && wm != null) {
            try {
                wm.removeView(container);
            } catch (Exception ignored) {
            }
            container = null;
        }
        stopSelf();
    }

    /** 把主界面选好的线稿以 base64 注入到 HTML 显示。 */
    private void injectImage() {
        if (pendingImagePath == null || web == null) return;
        final String p = pendingImagePath;
        pendingImagePath = null;
        try {
            File f = new File(p);
            FileInputStream fis = new FileInputStream(f);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = fis.read(b)) != -1) bos.write(b, 0, n);
            fis.close();
            String b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            web.evaluateJavascript(
                    "window._loadLineart && window._loadLineart('data:image/png;base64," + b64 + "');",
                    null);
        } catch (Exception e) {
        }
    }

    /** 收起悬浮窗：缩成底部小条，露出屏幕切换应用。 */
    public void minimizeOverlay() {
        if (web != null) {
            web.post(new Runnable() {
                @Override public void run() { doMinimize(); }
            });
        } else {
            doMinimize();
        }
    }

    public void expandOverlay() {
        if (web != null) {
            web.post(new Runnable() {
                @Override public void run() { doExpand(); }
            });
        } else {
            doExpand();
        }
    }

    private void doMinimize() {
        if (container == null || wm == null) return;
        if (overlayBtn == null) {
            overlayBtn = new FrameLayout(this);
            overlayBtn.setBackgroundColor(0xEE0B1220);
            TextView tv = new TextView(this);
            tv.setText("展开悬浮窗");
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(14);
            tv.setGravity(Gravity.CENTER);
            overlayBtn.addView(tv, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            overlayBtn.setOnClickListener(v -> expandOverlay());
            container.addView(overlayBtn, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        }
        web.setVisibility(View.GONE);
        overlayBtn.setVisibility(View.VISIBLE);
        try {
            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) container.getLayoutParams();
            lp.width = dp(250);
            lp.height = dp(56);
            lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            wm.updateViewLayout(container, lp);
        } catch (Exception ignored) {
        }
    }

    private void doExpand() {
        if (container == null || wm == null) return;
        if (overlayBtn != null) overlayBtn.setVisibility(View.GONE);
        web.setVisibility(View.VISIBLE);
        try {
            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) container.getLayoutParams();
            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
            lp.height = WindowManager.LayoutParams.MATCH_PARENT;
            lp.gravity = Gravity.TOP | Gravity.START;
            wm.updateViewLayout(container, lp);
        } catch (Exception ignored) {
        }
    }

    private int dp(int v) {
        return Math.round(getResources().getDisplayMetrics().density * v);
    }

    @Override
    public void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        if (container != null && wm != null) {
            try {
                wm.removeView(container);
            } catch (Exception ignored) {
            }
            container = null;
        }
        super.onDestroy();
    }
}
