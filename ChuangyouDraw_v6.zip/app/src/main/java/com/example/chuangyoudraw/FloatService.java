package com.example.chuangyoudraw;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

/**
 * 悬浮窗服务：把承载工具界面的 WebView 作为系统悬浮窗盖在“创游世界”上层。
 * - WebView 背景透明、页面用半透明模式，透出画板用于对齐
 * - 配 WebChromeClient，使“导入线稿”能弹出系统文件选择器
 * - 提供 close()，供 HTML 内“关闭”按钮通过桥接调用，可退出悬浮窗
 */
public class FloatService extends Service {

    private WindowManager wm;
    private FrameLayout container;
    private WebView web;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        // 前台服务：保证悬浮窗稳定，并允许从悬浮窗弹出系统文件选择器
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    "float", "悬浮窗服务", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
        Notification notif = new Notification.Builder(this, "float")
                .setContentTitle("创游世界描摹工具")
                .setContentText("悬浮窗运行中，可返回画板对齐")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .build();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                // Android 10+ 必须显式指定与 Manifest 一致的前台服务类型，否则崩溃
                startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            } else {
                startForeground(1, notif);
            }
        } catch (Exception e) {
            // 通知权限未授予等极端情况：忽略，悬浮窗仍可运行
        }

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        container = new FrameLayout(this);
        container.setBackgroundColor(0x99060A12);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowFileAccess(true);
        web.setBackgroundColor(0x00000000);

        // 注入桥接（含关闭悬浮窗回调）
        web.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");

        // 文件选择：让“导入线稿原图”能弹出系统文件选择器
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view,
                                             ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                FilePickActivity.start(FloatService.this, filePathCallback);
                return true;
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("document.body.classList.add('overlay');", null);
            }
        });

        web.loadUrl("file:///android_asset/tool.html");

        container.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        // 全屏悬浮窗；不设 NOT_FOCUSABLE，保证下拉框、文件选择等控件可正常交互
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        wm.addView(container, lp);
    }

    public WebView getWebView() {
        return web;
    }

    /** HTML 内“关闭”按钮调用：退出悬浮窗。 */
    public void close() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        if (container != null && wm != null) {
            try {
                wm.removeView(container);
            } catch (Exception ignored) {
            }
            container = null;
        }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        if (container != null && wm != null) {
            try {
                wm.removeView(container);
            } catch (Exception ignored) {
            }
            container = null;
        }
        super.onDestroy();
    }
}
