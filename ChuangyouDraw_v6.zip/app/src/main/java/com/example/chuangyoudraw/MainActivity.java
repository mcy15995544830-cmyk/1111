package com.example.chuangyoudraw;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.Manifest;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Toast;

/**
 * 主界面：申请悬浮窗权限、启动/关闭悬浮窗、跳转无障碍设置。
 */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Android 13+：悬浮窗前台服务需要通知权限
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }

        Button start = findViewById(R.id.btnStart);
        Button perm  = findViewById(R.id.btnPerm);
        Button stop  = findViewById(R.id.btnStop);

        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "需要先授予“显示在其他应用上层”权限", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
                return;
            }
            // Android 13+：前台服务需要通知权限，未授予就引导授权，否则启动会崩溃
            if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "请先允许“通知”权限（悬浮窗前台服务需要），授权后再点一次开启", Toast.LENGTH_LONG).show();
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
                return;
            }
            Intent svc = new Intent(this, FloatService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(svc);
            } else {
                startService(svc);
            }
            Toast.makeText(this,
                    "悬浮窗已开启。请再到系统【无障碍】里打开本应用的“自动绘制服务”，否则无法自动点击画板。",
                    Toast.LENGTH_LONG).show();
        });

        perm.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        stop.setOnClickListener(v -> stopService(new Intent(this, FloatService.class)));
    }
}
